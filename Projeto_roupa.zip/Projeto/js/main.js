// ============================================
// INICIALIZAÇÃO E VARIÁVEIS GLOBAIS
// ============================================

let cart = JSON.parse(localStorage.getItem('cart')) || [];
let currentFilter = 'all';

// Atualiza contador do carrinho ao carregar
updateCartCount();

// ============================================
// NAVBAR - Menu Hamburger e Scroll
// ============================================

const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const navbar = document.getElementById('navbar');

// Toggle menu mobile
if (hamburger) {
    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        hamburger.classList.toggle('active');
    });
}

// Fechar menu ao clicar em um link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    });
});

// Navbar transparente ao rolar
window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// ============================================
// CARRINHO DE COMPRAS
// ============================================

function addToCart(id, name, price) {
    // Verifica se o produto já está no carrinho
    const existingItem = cart.find(item => item.id === id);
    
    if (existingItem) {
        existingItem.quantity += 1;
        showNotification('Quantidade atualizada no carrinho!', 'success');
    } else {
        cart.push({
            id: id,
            name: name,
            price: price,
            quantity: 1
        });
        showNotification('Produto adicionado ao carrinho!', 'success');
    }
    
    // Salva no localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Atualiza contador
    updateCartCount();
    
    // Animação do botão
    animateCartIcon();
}

function updateCartCount() {
    const cartCount = document.getElementById('cartCount');
    if (cartCount) {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = totalItems;
        
        // Animação ao atualizar
        cartCount.style.transform = 'scale(1.3)';
        setTimeout(() => {
            cartCount.style.transform = 'scale(1)';
        }, 300);
    }
}

function animateCartIcon() {
    const cartIcon = document.querySelector('.cart-icon');
    if (cartIcon) {
        cartIcon.style.animation = 'bounce 0.5s';
        setTimeout(() => {
            cartIcon.style.animation = '';
        }, 500);
    }
}

// ============================================
// SISTEMA DE NOTIFICAÇÕES
// ============================================

function showNotification(message, type = 'info') {
    // Remove notificação anterior se existir
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Cria nova notificação
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Adiciona estilos
    Object.assign(notification.style, {
        position: 'fixed',
        top: '100px',
        right: '20px',
        background: type === 'success' ? 'linear-gradient(135deg, #00d4ff 0%, #0096c7 100%)' : '#1a1a1a',
        color: '#fff',
        padding: '15px 25px',
        borderRadius: '50px',
        boxShadow: '0 10px 40px rgba(0, 212, 255, 0.3)',
        zIndex: '9999',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        animation: 'slideInRight 0.5s ease-out',
        fontWeight: '600'
    });
    
    document.body.appendChild(notification);
    
    // Remove após 3 segundos
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.5s ease-out';
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

// Adiciona animações CSS para notificações
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ============================================
// FILTRO DE PRODUTOS
// ============================================

const filterButtons = document.querySelectorAll('.filter-btn');
const productCards = document.querySelectorAll('.product-card');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Remove active de todos os botões
        filterButtons.forEach(btn => btn.classList.remove('active'));
        
        // Adiciona active ao botão clicado
        button.classList.add('active');
        
        const filter = button.getAttribute('data-filter');
        currentFilter = filter;
        
        // Filtra produtos
        productCards.forEach(card => {
            const category = card.getAttribute('data-category');
            
            if (filter === 'all' || category === filter) {
                card.style.display = 'block';
                card.style.animation = 'fadeInScale 0.5s ease-out';
            } else {
                card.style.display = 'none';
            }
        });
    });
});

// Adiciona animação de filtro
const filterStyle = document.createElement('style');
filterStyle.textContent = `
    @keyframes fadeInScale {
        from {
            opacity: 0;
            transform: scale(0.8);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
`;
document.head.appendChild(filterStyle);

// ============================================
// VER DETALHES DO PRODUTO
// ============================================

function viewProduct(id) {
    // Salva o ID do produto no sessionStorage
    sessionStorage.setItem('selectedProduct', id);
    
    // Redireciona para página de detalhes
    window.location.href = 'pages/produto.html';
}

// ============================================
// SCROLL TO TOP
// ============================================

const scrollTopBtn = document.getElementById('scrollTop');

window.addEventListener('scroll', () => {
    if (window.scrollY > 500) {
        scrollTopBtn.classList.add('active');
    } else {
        scrollTopBtn.classList.remove('active');
    }
});

if (scrollTopBtn) {
    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// ============================================
// ANIMAÇÕES AOS (Animate on Scroll)
// ============================================

function initAOS() {
    const aosElements = document.querySelectorAll('[data-aos]');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('aos-animate');
            }
        });
    }, {
        threshold: 0.1
    });
    
    aosElements.forEach(el => observer.observe(el));
}

// Inicializa AOS quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', initAOS);

// ============================================
// NEWSLETTER
// ============================================

const newsletterForm = document.querySelector('.newsletter-form');

if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const email = newsletterForm.querySelector('input[type="email"]').value;
        
        if (email) {
            showNotification('Inscrição realizada com sucesso!', 'success');
            newsletterForm.reset();
        }
    });
}

// ============================================
// BUSCA DE PRODUTOS
// ============================================

const searchInput = document.querySelector('.search-box input');

if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        
        productCards.forEach(card => {
            const productName = card.querySelector('.product-name').textContent.toLowerCase();
            const productDesc = card.querySelector('.product-description').textContent.toLowerCase();
            
            if (productName.includes(searchTerm) || productDesc.includes(searchTerm)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
}

// ============================================
// SMOOTH SCROLL PARA ÂNCORAS
// ============================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const target = document.querySelector(this.getAttribute('href'));
        
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ============================================
// PRELOADER (Opcional)
// ============================================

window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});

// ============================================
// LOG DE DESENVOLVIMENTO
// ============================================

console.log('%c JSStore E-commerce ', 'background: linear-gradient(135deg, #00d4ff 0%, #0096c7 100%); color: white; font-size: 20px; padding: 10px; border-radius: 5px;');
console.log('Desenvolvido com HTML, CSS e JavaScript');
console.log('Cart items:', cart.length);